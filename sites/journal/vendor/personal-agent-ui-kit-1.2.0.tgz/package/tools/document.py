#!/usr/bin/env python3
"""Create and maintain UI Kit editable-report-v1 documents. No network access.

All writes create new outputs. SDK assets come from an explicit, versioned package;
content and saved edits stay in the document. Not an arbitrary HTML converter.
"""
import argparse
import hashlib
import html
import json
import re
import shutil
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit, unquote
sys.dont_write_bytecode = True
from body import Body

CSS = ('tokens.css', 'seomun.css', 'document.css')
JS = ('lucide.js', 'seomun.js', 'document.js')
NAMES = CSS + JS
ASSETS = re.compile(r'<(?:style|script)\b[^>]*\bdata-doc-asset\b[^>]*>.*?</(?:style|script)>|<link\b[^>]*\bdata-doc-asset\b[^>]*>', re.I | re.S)
META = re.compile(r'<script\b[^>]*\bid=["\']ui-kit-meta["\'][^>]*>(.*?)</script>', re.I | re.S)
DATA = re.compile(r'(<script\b[^>]*\bid=["\']document-data["\'][^>]*>)(.*?)(</script>)', re.I | re.S)


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def safe_js(text):
    return re.sub(r'</script', r'<\\/script', text, flags=re.I)


def json_text(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


class StartTag(HTMLParser):
    def handle_starttag(self, tag, attrs):
        if not hasattr(self, 'tag'):
            self.tag, self.attrs = tag, dict(attrs)


class BundleInventory(HTMLParser):
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'base':
            raise ValueError('Document base URL overrides are not supported')
        if tag == 'script' and attrs.get('id') not in {'document-data', 'ui-kit-meta'} and 'data-doc-asset' not in attrs:
            raise ValueError('Unmanaged executable script in document')
        if (tag == 'style' or (tag == 'link' and attrs.get('rel') == 'stylesheet')) and 'data-doc-asset' not in attrs:
            raise ValueError('Unmanaged stylesheet in document')


class Fields(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.values, self.field, self.title_id = {}, None, None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if self.field is not None:
            raise ValueError('Only plain-text edit fields are supported')
        if 'data-edit-id' in attrs:
            key = attrs['data-edit-id']
            if not key or key in self.values:
                raise ValueError('Missing or duplicate edit ID')
            self.field = key
            self.values[key] = ''
            if attrs.get('id') == 'report-title':
                self.title_id = key

    def handle_data(self, text):
        if self.field is not None:
            self.values[self.field] += text

    def handle_endtag(self, tag):
        self.field = None


def parse_body(main, template, fresh=False):
    reserved = set(re.findall(r'\bid="([^"]+)"', template)) - {'report', 'report-title'}
    body = Body(reserved, fresh=fresh)
    body.feed(main)
    body.finish()
    fields = Fields()
    fields.feed(main)
    if not fields.title_id or not fields.values[fields.title_id].strip():
        raise ValueError('The document needs a nonempty editable title')
    return body, fields


def read_document(text):
    main = re.search(r'<main\b[^>]*\bid=["\']report["\'][^>]*>.*?</main>', text, re.S)
    data = DATA.search(text)
    if not main or not data:
        raise ValueError('Expected #report and #document-data')
    data = json.loads(data[2])
    if data.get('schema') != 'editable-report-v1':
        raise ValueError('Unsupported document schema')
    fields = Fields()
    fields.feed(main[0])
    if not fields.title_id or set(fields.values) != set(data.get('values', {})):
        raise ValueError('Document data and editable field IDs do not match')
    # Saved DOM values outrank stale generation data, including a renamed title.
    data['values'] = fields.values
    return main[0], data, fields.values[fields.title_id]


def document_meta(text):
    matches = list(META.finditer(text))
    if len(matches) > 1:
        raise ValueError('Duplicate UI Kit metadata')
    return json.loads(matches[0][1]) if matches else None


def asset_elements(text):
    result = []
    for match in ASSETS.finditer(text):
        parser = StartTag()
        parser.feed(match[0].split('>', 1)[0] + '>')
        content = match[0].split('>', 1)[1].rsplit('</', 1)[0] if parser.tag != 'link' else ''
        result.append((match, parser.tag, parser.attrs, content))
    if len(result) != len(NAMES):
        raise ValueError('Expected the complete six-asset document bundle')
    return result


class Package:
    def __init__(self, root):
        root = Path(root).expanduser().resolve()
        if (root / 'packages/ui-kit/manifest.json').is_file():
            root /= 'packages/ui-kit'
        self.root = root
        self.manifest = json.loads((root / 'manifest.json').read_text())
        if self.manifest.get('name') != '@personal-agent/ui-kit' or self.manifest.get('documentSchema') != 'editable-report-v1':
            raise ValueError('Unsupported UI Kit package')
        self.version = self.manifest['version']
        self.template = (root / 'templates/document-shell.html').read_text()
        self.assets = {}
        for name in NAMES:
            item = self.manifest['assets'][name]
            path = (root / item['path']).resolve()
            if not path.is_relative_to(root):
                raise ValueError('Asset path is outside the package')
            raw = path.read_text()
            content = safe_js(raw) if name in JS else raw
            if digest(content) != item['sha256']:
                raise ValueError(f'Package asset modified: {name}')
            self.assets[name] = content

    def for_version(self, version):
        if version == self.version:
            return self
        if not re.fullmatch(r'\d+\.\d+\.\d+(?:-[\w.-]+)?', version):
            raise ValueError('Invalid SDK version')
        candidates = [self.root.parent / version]
        for parent in self.root.parents:
            candidates.extend([parent / 'dist/releases' / version, parent / 'releases' / version])
        for candidate in candidates:
            if (candidate / 'manifest.json').is_file():
                package = Package(candidate)
                if package.version == version:
                    return package
        raise ValueError(f'SDK {version} is not installed; provide its package with --from-sdk')

    def metadata(self, mode, base=None):
        data = {'sdkVersion': self.version, 'documentSchema': 'editable-report-v1', 'assetMode': mode,
                'assetHashes': {n: self.manifest['assets'][n]['sha256'] for n in NAMES}}
        if mode == 'linked':
            data['assetBase'] = base
        return data

    def asset_tags(self, mode, base=None):
        if mode == 'linked':
            url = urlsplit(base or '')
            if not base or url.scheme or url.netloc or '?' in base or '#' in base:
                raise ValueError('Linked assets require a same-origin path, not a CDN URL')
        tags = []
        for name in NAMES:
            escaped = html.escape(name, quote=True)
            if mode == 'embedded':
                tag = 'style' if name in CSS else 'script'
                tags.append(f'<{tag} data-doc-asset="{escaped}">{self.assets[name]}</{tag}>')
            else:
                url = html.escape(base.rstrip('/') + '/' + self.manifest['assets'][name]['path'], quote=True)
                tags.append(f'<link rel="stylesheet" data-doc-asset="{escaped}" href="{url}">' if name in CSS else f'<script data-doc-asset="{escaped}" src="{url}" defer></script>')
        return tags

    def verify(self, text, source, from_package=None):
        BundleInventory().feed(text)
        main, data, title = read_document(text)
        parse_body(main, self.template)
        elements = asset_elements(text)
        meta = document_meta(text)
        if meta:
            if meta.get('documentSchema') != data['schema'] or meta.get('assetMode') not in {'embedded', 'linked'}:
                raise ValueError('Unsupported document metadata')
            original = from_package or self.for_version(meta['sdkVersion'])
            if original.version != meta['sdkVersion']:
                raise ValueError('Source SDK version does not match document')
            wanted = {n: original.manifest['assets'][n]['sha256'] for n in NAMES}
            if meta.get('assetHashes') != wanted:
                raise ValueError('Document asset metadata differs from its selected SDK')
        else:
            original = None
            wanted = None
            if not re.search(r'<meta\b(?=[^>]*name=["\']ui-kit-document["\'])(?=[^>]*content=["\']1\.3\.0["\'])[^>]*>', text):
                raise ValueError('Only the known 1.3.0 legacy profile can be migrated')
        found = {}
        for name, (_, tag, attrs, content) in zip(NAMES, elements):
            logical = attrs.get('data-doc-asset')
            if logical not in (None, '', name) or (meta and logical != name):
                raise ValueError(f'Asset order or identity changed: {name}')
            linked = tag == 'link' or 'src' in attrs
            if (name in CSS and tag not in {'style', 'link'}) or (name in JS and tag != 'script'):
                raise ValueError(f'Asset type changed: {name}')
            if meta and linked != (meta['assetMode'] == 'linked'):
                raise ValueError('Mixed embedded and linked SDK assets')
            if linked:
                value = attrs.get('href' if tag == 'link' else 'src', '')
                url = urlsplit(value)
                if url.scheme or url.netloc or url.query or url.fragment:
                    raise ValueError('Expected a local or same-origin asset path')
                if meta:
                    expected = meta['assetBase'].rstrip('/') + '/' + original.manifest['assets'][name]['path']
                    if value != expected:
                        raise ValueError(f'Linked asset path changed: {name}')
                local = source.parent / unquote(url.path)
                if local.is_file():
                    content = local.read_text()
                    if name in JS:
                        content = safe_js(content)
                elif original:
                    content = original.assets[name]
                else:
                    raise ValueError(f'Legacy linked asset unavailable: {value}')
            found[name] = digest(content)
        if wanted:
            if found != wanted:
                raise ValueError('Managed SDK assets were modified; automatic replacement stopped')
        else:
            legacy = json.loads((self.root / 'tools/legacy-assets.json').read_text())
            if not any(found == bundle['hashes'] for bundle in legacy['bundles']):
                raise ValueError('Unknown or modified legacy SDK assets; automatic replacement stopped')
        return main, data, title


def require_offline(main):
    class Media(HTMLParser):
        def handle_starttag(self, tag, attrs):
            for key, value in attrs:
                if key in {'src', 'srcset', 'poster'} and not (value or '').startswith('data:'):
                    raise ValueError(f'Embed document media as data URLs before export: {value}')
    Media().feed(main)


def render(package, main, data, title, theme, mode, base=None):
    tags = package.asset_tags(mode, base)
    values = {'TITLE': html.escape(title), 'THEME_KEY': html.escape(theme, quote=True), 'MAIN': main,
              'STYLES': '\n'.join(tags[:3]), 'SCRIPTS': '\n'.join(tags[3:]), 'DATA': json_text(data),
              'SDK_META': '<script id="ui-kit-meta" type="application/json">' + json_text(package.metadata(mode, base)) + '</script>'}
    return re.sub(r'\{\{([A-Z_]+)\}\}', lambda m: values[m[1]], package.template)


def replace_assets(package, text, data, mode, base=None):
    tags = iter(package.asset_tags(mode, base))
    text = ASSETS.sub(lambda _: next(tags), text)
    metadata = '<script id="ui-kit-meta" type="application/json">' + json_text(package.metadata(mode, base)) + '</script>'
    text = META.sub(lambda _: metadata, text) if META.search(text) else text.replace('</head>', metadata + '\n</head>', 1)
    # Only sync the edit-value snapshot, without resetting filenames or other config.
    return DATA.sub(lambda m: m[1] + json_text(data) + m[3], text, count=1)


def install_linked(package, destination):
    # Shared immutable assets beside linked outputs; compare existing files, never overwrite.
    files = ['manifest.json'] + [package.manifest['assets'][n]['path'] for n in NAMES]
    for folder in ['upstream']:
        files += [str(p.relative_to(package.root)) for p in (package.root / folder).rglob('*') if p.is_file()]
    for name in files:
        src, target = package.root / name, destination / name
        if target.exists() and target.read_bytes() != src.read_bytes():
            raise ValueError(f'Existing linked SDK differs: {target}')
    for name in files:
        src, target = package.root / name, destination / name
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(src.read_bytes())


def run(args):
    package = Package(args.sdk or Path(__file__).resolve().parents[1])
    if args.version:
        package = package.for_version(args.version)
    if args.command == 'source':
        return {'package': package.manifest['name'], 'version': package.version, 'sdk': str(package.root), 'documentSchema': package.manifest['documentSchema']}
    source = args.source.expanduser().resolve()
    raw = source.read_bytes()
    text = raw.decode('utf-8-sig')
    from_package = Package(args.from_sdk) if args.from_sdk else None
    if args.command == 'check':
        _, data, _ = package.verify(text, source, from_package)
        meta = document_meta(text)
        return {'version': meta['sdkVersion'] if meta else 'legacy-1.3.0', 'mode': meta['assetMode'] if meta else 'legacy', 'fields': len(data['values']), 'assetsMatch': True}
    output = args.output.expanduser().resolve()
    if source == output or output.exists() or args.output.is_symlink() or output.suffix.lower() != '.html':
        raise ValueError('Choose a new .html output; existing files are never overwritten')
    if args.command == 'document':
        main = text.strip()
        shape, fields = parse_body(main, package.template, fresh=True)
        title = fields.values[fields.title_id]
        data = {'schema': 'editable-report-v1', 'values': fields.values, 'head': [{'type':'title','id':fields.title_id}], 'sections': shape.chapters, 'suggestedFilename': output.stem + '_수정본.html'}
    else:
        main, data, title = package.verify(text, source, from_package)
        old = document_meta(text)
        # Export/conversion preserve the selected release; only update changes it.
        if args.command in {'export', 'convert'} and old:
            package = from_package or package.for_version(old['sdkVersion'])
    mode = 'embedded' if args.command == 'export' else args.mode
    base = (args.asset_base or f'ui-kit/{package.version}') if mode == 'linked' else None
    if mode == 'embedded':
        require_offline(main)
    if args.command == 'document':
        result = render(package, main, data, title, args.theme_key or f'ui-kit-document:{output.stem}:theme', mode, base)
    else:
        result = replace_assets(package, text, data, mode, base)
    new_main, new_data, _ = read_document(result)
    if new_main != main or new_data != data:
        raise ValueError('Document content or configuration changed during conversion')
    if source.read_bytes() != raw:
        raise ValueError('Source changed during conversion; retry from the current file')
    # Read the selected package again immediately before writing, rather than
    # allowing a concurrent build to silently mix release assets.
    current = Package(package.root)
    if current.manifest != package.manifest or current.assets != package.assets:
        raise ValueError('SDK changed during conversion')
    if mode == 'linked' and not args.asset_base:
        install_linked(package, output.parent / base)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8') as stream:
        stream.write(result)
    return {'output': str(output), 'version': package.version, 'mode': mode, 'fields': len(data['values'])}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ['source', 'document', 'update', 'reapply', 'export', 'convert', 'check']:
        cmd = commands.add_parser(name)
        cmd.add_argument('--sdk', '--kit-root', dest='sdk', help='UI Kit package or source checkout')
        cmd.add_argument('--version', help='Exact installed release version')
        cmd.add_argument('--from-sdk', help='Source document SDK, when updating an older release')
        if name != 'source':
            cmd.add_argument('source', type=Path)
        if name not in {'source','check'}:
            cmd.add_argument('output', type=Path)
            cmd.add_argument('--mode', choices=['embedded','linked'], default='embedded')
            cmd.add_argument('--asset-base', help='App-served same-origin version directory')
            cmd.add_argument('--theme-key', default='')
    args = parser.parse_args(argv)
    try:
        print(json.dumps(run(args), ensure_ascii=False, indent=2))
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(1, f'UI Kit: {error}\n')


if __name__ == '__main__':
    main()
