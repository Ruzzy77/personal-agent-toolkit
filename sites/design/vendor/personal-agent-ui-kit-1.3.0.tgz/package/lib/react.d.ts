import type {ComponentProps, ReactNode} from 'react';
import {Select} from '@openai/apps-sdk-ui/components/Select';
import {CopyTooltip} from '@openai/apps-sdk-ui/components/Tooltip';
export function NamedControl(props: {label: string; selector?: string; restoreFocus?: boolean; visibleLabel?: boolean; children: ReactNode}): ReactNode;
export function FieldSelect(props: ComponentProps<typeof Select> & {'aria-label': string; visibleLabel?: boolean; restoreFocus?: boolean}): ReactNode;
export function Field(props: {label: string; children: ReactNode}): ReactNode;
export function KeyboardCopyTooltip(props: ComponentProps<typeof CopyTooltip>): ReactNode;
export function installCalendarNames(root?: Document | HTMLElement): () => void;
export {initPageNavigation} from './page-navigation.js';
