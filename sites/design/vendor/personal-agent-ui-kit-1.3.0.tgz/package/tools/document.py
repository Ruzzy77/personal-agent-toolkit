#!/usr/bin/env python3
"""Create and maintain UI Kit editable-report-v1 documents. No network access.

All writes create new outputs. SDK assets come from an explicit, versioned package;
content and saved edits stay in the document. Not an arbitrary HTML converter.
"""
import argparse
import html
import json
import os
import re
import sys
import tempfile
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit, unquote
sys.dont_write_bytecode = True
from body import Body
from sdk_assets import ASSET_ORDER, Package as AssetPackage, digest, safe_js

CSS = ASSET_ORDER[:3]
JS = ASSET_ORDER[3:]
NAMES = CSS + JS
ASSETS = re.compile(r'<(?:style|script)\b[^>]*\bdata-doc-asset\b[^>]*>.*?</(?:style|script)>|<link\b[^>]*\bdata-doc-asset\b[^>]*>', re.I | re.S)
META = re.compile(r'<script\b[^>]*\bid=["\']ui-kit-meta["\'][^>]*>(.*?)</script>', re.I | re.S)
DATA = re.compile(r'(<script\b[^>]*\bid=["\']document-data["\'][^>]*>)(.*?)(</script>)', re.I | re.S)


def json_text(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


class StartTag(HTMLParser):
    def handle_starttag(self, tag, attrs):
        if not hasattr(self, 'tag'):
            self.tag, self.attrs = tag, dict(attrs)


class BundleInventory(HTMLParser):
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'base':
            raise ValueError('Document base URL overrides are not supported')
        if tag == 'script' and attrs.get('id') not in {'document-data', 'ui-kit-meta'} and 'data-doc-asset' not in attrs and 'data-app-asset' not in attrs:
            raise ValueError('Unmanaged executable script in document')
        if (tag == 'style' or (tag == 'link' and attrs.get('rel') == 'stylesheet')) and 'data-doc-asset' not in attrs and 'data-app-asset' not in attrs:
            raise ValueError('Unmanaged stylesheet in document')


class Fields(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.values, self.field, self.title_id = {}, None, None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if self.field is not None:
            raise ValueError('Only plain-text edit fields are supported')
        if 'data-edit-id' in attrs:
            key = attrs['data-edit-id']
            if not key or key in self.values:
                raise ValueError('Missing or duplicate edit ID')
            self.field = key
            self.values[key] = ''
            if attrs.get('id') == 'report-title':
                self.title_id = key

    def handle_data(self, text):
        if self.field is not None:
            self.values[self.field] += text

    def handle_endtag(self, tag):
        self.field = None


def parse_body(main, template, fresh=False):
    reserved = set(re.findall(r'\bid="([^"]+)"', template)) - {'report', 'report-title'}
    body = Body(reserved, fresh=fresh)
    body.feed(main)
    body.finish()
    fields = Fields()
    fields.feed(main)
    if not fields.title_id or not fields.values[fields.title_id].strip():
        raise ValueError('The document needs a nonempty editable title')
    return body, fields


def read_document(text):
    main = re.search(r'<main\b[^>]*\bid=["\']report["\'][^>]*>.*?</main>', text, re.S)
    data = DATA.search(text)
    if not main or not data:
        raise ValueError('Expected #report and #document-data')
    data = json.loads(data[2])
    if data.get('schema') != 'editable-report-v1':
        raise ValueError('Unsupported document schema')
    fields = Fields()
    fields.feed(main[0])
    if not fields.title_id or set(fields.values) != set(data.get('values', {})):
        raise ValueError('Document data and editable field IDs do not match')
    # Saved DOM values outrank stale generation data, including a renamed title.
    data['values'] = fields.values
    return main[0], data, fields.values[fields.title_id]


def document_meta(text):
    matches = list(META.finditer(text))
    if len(matches) > 1:
        raise ValueError('Duplicate UI Kit metadata')
    return json.loads(matches[0][1]) if matches else None


def asset_elements(text):
    result = []
    for match in ASSETS.finditer(text):
        parser = StartTag()
        parser.feed(match[0].split('>', 1)[0] + '>')
        content = match[0].split('>', 1)[1].rsplit('</', 1)[0] if parser.tag != 'link' else ''
        result.append((match, parser.tag, parser.attrs, content))
    if len(result) != len(NAMES):
        raise ValueError('Expected the complete six-asset document bundle')
    return result


def verify_document(package, text, source, from_package=None):
        BundleInventory().feed(text)
        main, data, title = read_document(text)
        parse_body(main, package.template)
        elements = asset_elements(text)
        meta = document_meta(text)
        if meta:
            if meta.get('documentSchema') != data['schema'] or meta.get('assetMode') not in {'embedded', 'linked'}:
                raise ValueError('Unsupported document metadata')
            original = from_package or package.for_version(meta['sdkVersion'])
            if original.version != meta['sdkVersion']:
                raise ValueError('Source SDK version does not match document')
            wanted = {n: original.manifest['assets'][n]['sha256'] for n in NAMES}
            if meta.get('assetHashes') != wanted:
                raise ValueError('Document asset metadata differs from its selected SDK')
        else:
            original = None
            wanted = None
            if not re.search(r'<meta\b(?=[^>]*name=["\']ui-kit-document["\'])(?=[^>]*content=["\']1\.3\.0["\'])[^>]*>', text):
                raise ValueError('Only the known 1.3.0 legacy profile can be migrated')
        found = {}
        for name, (_, tag, attrs, content) in zip(NAMES, elements):
            logical = attrs.get('data-doc-asset')
            if logical not in (None, '', name) or (meta and logical != name):
                raise ValueError(f'Asset order or identity changed: {name}')
            linked = tag == 'link' or 'src' in attrs
            if (name in CSS and tag not in {'style', 'link'}) or (name in JS and tag != 'script'):
                raise ValueError(f'Asset type changed: {name}')
            if meta and linked != (meta['assetMode'] == 'linked'):
                raise ValueError('Mixed embedded and linked SDK assets')
            if linked:
                value = attrs.get('href' if tag == 'link' else 'src', '')
                url = urlsplit(value)
                if url.scheme or url.netloc or url.query or url.fragment:
                    raise ValueError('Expected a local or same-origin asset path')
                if meta:
                    expected = meta['assetBase'].rstrip('/') + '/' + original.manifest['assets'][name]['path']
                    if value != expected:
                        raise ValueError(f'Linked asset path changed: {name}')
                local = source.parent / unquote(url.path)
                if local.is_file():
                    content = local.read_text()
                    if name in JS:
                        content = safe_js(content)
                elif original:
                    content = original.assets[name]
                else:
                    raise ValueError(f'Legacy linked asset unavailable: {value}')
            found[name] = digest(content)
        if wanted:
            if found != wanted:
                raise ValueError('Managed SDK assets were modified; automatic replacement stopped')
        else:
            legacy = json.loads((package.root / 'tools/legacy-assets.json').read_text())
            if not any(found == bundle['hashes'] for bundle in legacy['bundles']):
                raise ValueError('Unknown or modified legacy SDK assets; automatic replacement stopped')
        return main, data, title


class Package(AssetPackage):
    """Document package compatibility facade with document validation."""

    def for_version(self, version):
        package = super().for_version(version)
        return self if package.root == self.root else Package(package.root)

    def verify(self, text, source, from_package=None):
        return verify_document(self, text, source, from_package)


def require_offline(main):
    class Media(HTMLParser):
        def handle_starttag(self, tag, attrs):
            for key, value in attrs:
                if key in {'src', 'srcset', 'poster'} and not (value or '').startswith('data:'):
                    raise ValueError(f'Embed document media as data URLs before export: {value}')
    Media().feed(main)


def render(package, main, data, title, theme, mode, base=None):
    tags = package.asset_tags(mode, base)
    values = {'TITLE': html.escape(title), 'THEME_KEY': html.escape(theme, quote=True), 'MAIN': main,
              'STYLES': '\n'.join(tags[:3]), 'SCRIPTS': '\n'.join(tags[3:]), 'DATA': json_text(data),
              'SDK_META': '<script id="ui-kit-meta" type="application/json">' + json_text(package.metadata(mode, base)) + '</script>'}
    return re.sub(r'\{\{([A-Z_]+)\}\}', lambda m: values[m[1]], package.template)


def replace_assets(package, text, data, mode, base=None):
    tags = iter(package.asset_tags(mode, base))
    text = ASSETS.sub(lambda _: next(tags), text)
    metadata = '<script id="ui-kit-meta" type="application/json">' + json_text(package.metadata(mode, base)) + '</script>'
    text = META.sub(lambda _: metadata, text) if META.search(text) else text.replace('</head>', metadata + '\n</head>', 1)
    # Only sync the edit-value snapshot, without resetting filenames or other config.
    return DATA.sub(lambda m: m[1] + json_text(data) + m[3], text, count=1)


def install_linked(package, destination):
    # Shared immutable assets beside linked outputs; compare existing files, never overwrite.
    files = ['manifest.json'] + [package.manifest['assets'][n]['path'] for n in NAMES]
    for folder in ['upstream']:
        files += [str(p.relative_to(package.root)) for p in (package.root / folder).rglob('*') if p.is_file()]
    for name in files:
        src, target = package.root / name, destination / name
        if target.exists() and target.read_bytes() != src.read_bytes():
            raise ValueError(f'Existing linked SDK differs: {target}')
    for name in files:
        src, target = package.root / name, destination / name
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(src.read_bytes())


EXCLUDED_FOLDERS = {
    '.git', '.next', '.venv', '__pycache__', 'archive', 'archives', 'backup', 'backups',
    'dist', 'node_modules', 'releases', 'target', 'ui-kit', 'vendor', '보관', '보관본', '원자료',
}


def version_key(version):
    match = re.fullmatch(r'(\d+)\.(\d+)\.(\d+)(?:-([\w.-]+))?', version or '')
    if not match:
        raise ValueError(f'Invalid SDK version: {version}')
    return tuple(map(int, match.groups()[:3])), match.group(4) is None


def linked_update_base(meta, target):
    current = meta.get('sdkVersion')
    base = meta.get('assetBase')
    if base != f'ui-kit/{current}':
        raise ValueError('Linked document uses an app-provided asset path; update it through that app')
    return f'ui-kit/{target}'


def batch_paths(inputs, recursive):
    found, explicit = [], set()
    for item in inputs:
        path = item.expanduser().absolute()
        if path.is_symlink():
            continue
        if path.is_file():
            explicit.add(path)
            found.append(path)
            continue
        if not path.is_dir():
            explicit.add(path)
            found.append(path)
            continue
        iterator = path.rglob('*.html') if recursive else path.glob('*.html')
        for candidate in iterator:
            relative = candidate.relative_to(path)
            if candidate.is_symlink() or any(part.casefold() in EXCLUDED_FOLDERS for part in relative.parts[:-1]):
                continue
            found.append(candidate.absolute())
    return list(dict.fromkeys(sorted(found, key=lambda value: str(value)))), explicit


def write_atomic(path, raw, original, package, data):
    descriptor, temporary = tempfile.mkstemp(prefix=f'.{path.stem}.ui-kit-', suffix='.html', dir=path.parent)
    temporary = Path(temporary)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, path.stat().st_mode)
        checked = temporary.read_text(encoding='utf-8')
        _, checked_data, _ = package.verify(checked, temporary)
        if checked_data != data:
            raise ValueError('Document content or configuration changed during update')
        if path.read_bytes() != original:
            raise ValueError('Source changed during update; retry from the current file')
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def batch_item(path, package, apply):
    result = {'path': str(path)}
    if not path.is_file():
        return result | {'status': 'failed', 'reason': 'File not found'}
    try:
        raw = path.read_bytes()
        text = raw.decode('utf-8-sig')
        meta = document_meta(text)
        if not DATA.search(text) or (meta and meta.get('documentSchema') != 'editable-report-v1'):
            return result | {'status': 'deferred', 'reason': 'Not a managed editable document'}
        current = meta.get('sdkVersion') if meta else 'legacy-1.3.0'
        result['fromVersion'] = current
        result['toVersion'] = package.version
        if meta and version_key(current) > version_key(package.version):
            return result | {'status': 'deferred', 'reason': 'Automatic downgrade is not supported'}
        main, data, _ = package.verify(text, path)
        if meta and current == package.version:
            return result | {'status': 'unchanged'}
        mode = meta.get('assetMode', 'embedded') if meta else 'embedded'
        base = linked_update_base(meta, package.version) if mode == 'linked' else None
        updated = replace_assets(package, text, data, mode, base)
        next_main, next_data, _ = read_document(updated)
        if next_main != main or next_data != data:
            raise ValueError('Document content or configuration changed during update')
        package.verify(updated, path)
        if not apply:
            return result | {'status': 'would-update', 'mode': mode}
        if mode == 'linked':
            install_linked(package, path.parent / base)
        write_atomic(path, updated.encode('utf-8'), raw, package, data)
        return result | {'status': 'updated', 'mode': mode}
    except (OSError, ValueError, KeyError, TypeError, UnicodeError, json.JSONDecodeError) as error:
        reason = str(error)
        status = 'deferred' if any(term in reason for term in (
            'modified', 'not installed', 'app-provided', 'Unsupported', 'Unknown or modified',
        )) else 'failed'
        return result | {'status': status, 'reason': reason}


def batch_update(args, package):
    paths, explicit = batch_paths(args.sources, args.recursive)
    items = []
    for path in paths:
        if path not in explicit:
            try:
                head = path.read_text(encoding='utf-8-sig')
            except (OSError, UnicodeError):
                continue
            if 'ui-kit-meta' not in head and 'ui-kit-document' not in head:
                continue
        items.append(batch_item(path, package, args.apply))
    counts = {status: sum(item['status'] == status for item in items) for status in ('would-update', 'updated', 'unchanged', 'deferred', 'failed')}
    return {'targetVersion': package.version, 'apply': args.apply, 'summary': counts, 'files': items}


def run(args):
    package = Package(args.sdk or Path(__file__).resolve().parents[1])
    if args.version:
        package = package.for_version(args.version)
    if args.command == 'source':
        return {'package': package.manifest['name'], 'version': package.version, 'sdk': str(package.root), 'documentSchema': package.manifest['documentSchema']}
    if args.command == 'batch-update':
        return batch_update(args, package)
    source = args.source.expanduser().resolve()
    raw = source.read_bytes()
    text = raw.decode('utf-8-sig')
    from_package = Package(args.from_sdk) if args.from_sdk else None
    if args.command == 'check':
        _, data, _ = package.verify(text, source, from_package)
        meta = document_meta(text)
        return {'version': meta['sdkVersion'] if meta else 'legacy-1.3.0', 'mode': meta['assetMode'] if meta else 'legacy', 'fields': len(data['values']), 'assetsMatch': True}
    output = args.output.expanduser().resolve()
    if source == output or output.exists() or args.output.is_symlink() or output.suffix.lower() != '.html':
        raise ValueError('Choose a new .html output; existing files are never overwritten')
    if args.command == 'document':
        main = text.strip()
        shape, fields = parse_body(main, package.template, fresh=True)
        title = fields.values[fields.title_id]
        data = {'schema': 'editable-report-v1', 'values': fields.values, 'head': [{'type':'title','id':fields.title_id}], 'sections': shape.chapters, 'suggestedFilename': output.stem + '_수정본.html'}
    else:
        main, data, title = package.verify(text, source, from_package)
        old = document_meta(text)
        # Export/conversion preserve the selected release; only update changes it.
        if args.command in {'export', 'convert'} and old:
            package = from_package or package.for_version(old['sdkVersion'])
    if args.command == 'export':
        mode = 'embedded'
    elif args.mode:
        mode = args.mode
    elif args.command in {'update', 'reapply'} and old:
        mode = old['assetMode']
    else:
        mode = 'embedded'
    if mode == 'linked':
        if args.asset_base:
            base = args.asset_base
        elif args.command in {'update', 'reapply'} and old:
            base = linked_update_base(old, package.version)
        else:
            base = f'ui-kit/{package.version}'
    else:
        base = None
    if mode == 'embedded':
        require_offline(main)
    if args.command == 'document':
        result = render(package, main, data, title, args.theme_key or f'ui-kit-document:{output.stem}:theme', mode, base)
    else:
        result = replace_assets(package, text, data, mode, base)
    new_main, new_data, _ = read_document(result)
    if new_main != main or new_data != data:
        raise ValueError('Document content or configuration changed during conversion')
    if source.read_bytes() != raw:
        raise ValueError('Source changed during conversion; retry from the current file')
    # Read the selected package again immediately before writing, rather than
    # allowing a concurrent build to silently mix release assets.
    current = Package(package.root)
    if current.manifest != package.manifest or current.assets != package.assets:
        raise ValueError('SDK changed during conversion')
    if mode == 'linked' and not args.asset_base:
        install_linked(package, output.parent / base)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8') as stream:
        stream.write(result)
    return {'output': str(output), 'version': package.version, 'mode': mode, 'fields': len(data['values'])}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ['source', 'document', 'update', 'reapply', 'export', 'convert', 'check']:
        cmd = commands.add_parser(name)
        cmd.add_argument('--sdk', '--kit-root', dest='sdk', help='UI Kit package or source checkout')
        cmd.add_argument('--version', help='Exact installed release version')
        cmd.add_argument('--from-sdk', help='Source document SDK, when updating an older release')
        if name != 'source':
            cmd.add_argument('source', type=Path)
        if name not in {'source','check'}:
            cmd.add_argument('output', type=Path)
            cmd.add_argument('--mode', choices=['embedded','linked'])
            cmd.add_argument('--asset-base', help='App-served same-origin version directory')
            cmd.add_argument('--theme-key', default='')
    batch = commands.add_parser('batch-update')
    batch.add_argument('sources', nargs='+', type=Path)
    batch.add_argument('--sdk', '--kit-root', dest='sdk', help='UI Kit package or source checkout')
    batch.add_argument('--version', required=True, help='Exact installed target release')
    batch.add_argument('--recursive', action='store_true')
    batch.add_argument('--apply', action='store_true')
    args = parser.parse_args(argv)
    try:
        print(json.dumps(run(args), ensure_ascii=False, indent=2))
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(1, f'UI Kit: {error}\n')


if __name__ == '__main__':
    main()
