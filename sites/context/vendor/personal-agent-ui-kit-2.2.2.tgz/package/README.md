# @personal-agent/ui-kit 2.2

토큰·테마·컴포넌트와 독립 편집 HTML 제작 도구입니다. Apps SDK UI는 0.2.2로 고정합니다. 기존 1.x 릴리스와 생성 문서는 변경하지 않습니다.

## CSS 진입점

| 경로 | 포함 범위 |
|---|---|
| tokens.css | data-uikit 범위의 원본 토큰과 공개 별칭 |
| theme.css | 기본·한글 편집형, 명암·밀도 선택 |
| components.css | 네이티브 HTML 어댑터 |
| layout.css | 행·열·묶음·선택형 상단바·작업 영역 |
| react.css | 토큰·테마와 공식 React의 이름·초점·대화상자 보완 |
| html.css | 토큰·테마·HTML 리셋·네이티브 컴포넌트 |
| document.css | 연속형 문서와 편집·찾기·저장 인터페이스 |
| editing.css | 문단 단위 편집 초점 표시, 기존 문서에 선택 적용 |
| pages.css | 작성자가 구분한 페이지형 문서 |

React 진입점에는 body 리셋, 상단바 규격, 문서 폭, A4 규격이 없습니다. HTML 리셋은 문서 전체를 소유하는 경우에만 사용합니다. 본문·앱의 열 비율과 읽기 순서는 소비 화면이 정합니다.

## React

기존 앱의 React 18/19, Tailwind 4, Apps SDK UI 0.2.2와 조합합니다.

```css
@layer theme, base, components, utilities;
@import "tailwindcss";
@import "@openai/apps-sdk-ui/css";
@import "@personal-agent/ui-kit/react.css";
@import "@personal-agent/ui-kit/layout.css";
@source "../node_modules/@openai/apps-sdk-ui/dist/es";
```

앱 진입점에서 위 스타일을 컴포넌트보다 먼저 가져옵니다. 단일 CSS로 합쳐도 layer 순서를 맨 앞에 유지합니다.

공식 CSS의 reset은 호스트 앱의 기존 통합 방침에 따릅니다. @source는 실제 설치 위치에 맞춥니다.

```jsx
import {UIKitRoot, Field, FieldSelect, Dialog} from '@personal-agent/ui-kit/react';
import {Button} from '@openai/apps-sdk-ui/components/Button';

<UIKitRoot theme="editorial-ko" colorScheme="system" density="comfortable">
  <Button onClick={save}>설정 저장</Button>
</UIKitRoot>
```

UIKitRoot는 문서당 하나입니다. documentElement의 테마 속성을 설정하여 body 아래의 공식 포털도 같은 토큰을 사용하게 합니다. 해제 시 원래 속성을 복원합니다. body 글꼴·여백·폭은 바꾸지 않고 내부 .uikit-surface에만 콘텐츠 서체를 적용합니다. 다른 테마를 동시에 시연할 때에는 iframe으로 분리합니다.

Field/FieldSelect는 실제 입력 요소에 이름을 연결합니다. description은 같은 필드 안의 보충 설명이며 aria-describedby로 입력에 연결됩니다. Dialog는 네이티브 showModal, Escape, 초점 복귀를 유지합니다. 메뉴 항목에서 열 때에는 returnFocusRef로 지속되는 메뉴 버튼을 지정합니다. ResponsiveNavigation과 NavigationAction은 기존 과업의 탐색 구조를 소비하며 정보 구조를 대신 정하지 않습니다.

Flow처럼 상위 앱이 밝기를 전달하는 HTML에는 UIKitRoot colorScheme="inherit"를 사용합니다. 이 모드는 data-theme를 쓰거나 복원하지 않으며 운영체제 밝기를 구독하지 않습니다. 기존 system/light/dark는 문서 밝기를 직접 관리합니다.

## 테마 확장

선택 축은 독립적입니다.
- data-uikit: openai / editorial-ko / 프로젝트 테마 이름
- data-color-scheme: system / light / dark / inherit
- data-density: comfortable / compact
- data-document-profile: continuous / pages

공개 토큰: --su-font, --su-heading-font, --su-leading, --su-text, --su-surface, --su-paper, --su-ink, --su-muted, --su-line, --su-focus, --su-control-gap, --su-stack-gap, --su-section-gap, --su-panel-padding. 공식 의미 토큰은 고정 upstream 정의를 따릅니다.

프로젝트 테마는 [data-uikit="project"] 아래에서 토큰을 재정의합니다. 열 비율·페이지별 최대 폭은 페이지 CSS에 둡니다. 컨트롤 내부 선택자를 깊게 덮어쓰지 않습니다. editorial-ko는 시스템 글꼴을 사용하며 폰트 파일·CDN 요청을 포함하지 않습니다.

## 상호작용 HTML

공통 제작 환경에 고정한 React, React DOM, Apps SDK UI 0.2.2, Tailwind와 Vite를 사용합니다. 제작 도구는 의존성을 자동 설치하지 않습니다.

```sh
node tools/screen.mjs App.jsx output.html --title "참고 자료"
```

입력은 기본으로 내보낸 React 컴포넌트입니다. App 안에 UIKitRoot를 한 번 배치합니다. 출력에는 root와 실행 코드만 들어가며 제목이나 편집 도구를 화면에 추가하지 않습니다. 공식 스타일은 앱보다 먼저 불러오고 layer 순서를 보존합니다. 앱의 CSS는 입력 파일에서 가져올 수 있으나 공식 스타일을 중복 수입하지 않습니다.

CSS와 JavaScript, 공식 수식 글꼴은 HTML에 내장합니다. Flow 자산 이름은 그대로 유지하여 작업물의 불변 자산 목록과 연결합니다. 외부 코드·스타일과 예기치 않은 별도 출력 파일은 거절합니다. 일반 상호작용 HTML에 편집 보고서 구조를 요구하지 않습니다.

## 독립 HTML

```sh
python3 -B tools/document.py document body.html report.html --theme editorial-ko --profile continuous
python3 -B tools/document.py check report.html
```

본문에는 하나의 main.document#report, 고유 data-edit-id를 가진 h1.report-title#report-title과 section.chapter/h2.chapter-title이 필요합니다. HTML 어댑터는 네이티브 구현이며 공식 React 컴포넌트와 동일한 구현이 아닙니다.

일반 텍스트 문단은 문단 자체에 data-edit-id를 둡니다. 화면의 줄바꿈이나 문장마다 필드를 나누지 않습니다. 수식·인용·강조가 섞인 문단은 data-edit-mode="inline"으로 편집합니다.

```html
<p data-edit-id="result" data-edit-mode="inline">
검사 대상 <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>x</mi></math>의
<strong>판정 결과</strong>를 확인합니다.<a href="#reference-1">[1]</a>
</p>
```

문단 안에서 커서 이동과 선택이 이어지며, 수식과 링크는 하나의 개체로 선택·복사·삭제할 수 있습니다. 수식 내부 기호와 링크 주소를 본문 입력으로 수정하는 기능은 제공하지 않습니다. 링크는 보조키(Ctrl/Command)를 누르고 클릭하거나 키보드로 실행할 수 있습니다. Enter는 현재 편집 단위 안에 줄바꿈을 넣습니다. 서로 다른 문단이나 표 셀을 하나의 편집 영역으로 합치지 않습니다.

혼합 문단의 부모 ID가 안정적인 편집 기준입니다. 신규 문서에서는 하위 텍스트마다 ID를 만들 필요가 없습니다. 전환한 문서의 기존 하위 ID는 유지하지만, 사용자가 해당 내용을 삭제·교체하면 그 하위 ID도 없어질 수 있습니다. 복사해 붙여 넣는 내용에는 중복 ID를 가져오지 않습니다.

새 문서 도구는 지원하는 인라인 구조를 문단 편집으로 정리합니다. 구조화된 내용은 editable-report-v2의 richValues에 저장하며 v1의 일반 텍스트 문서도 계속 지원합니다. 허용 태그와 속성은 lib/inline-policy.json에 정의합니다. UIKit에서 복사한 내용만 허용된 인라인 서식으로 붙여 넣고, 외부 내용은 일반 텍스트로 붙여 넣습니다.

editing.css는 문서 묶음에 포함됩니다. data-edit-group은 초점 표시만 묶으며, 문단 편집을 활성화하는 속성은 data-edit-mode입니다. 기존 1.x 문서에 초점 표시만 적용하려면 editing.css를 기존 스타일 뒤에 data-app-asset으로 내장할 수 있습니다. 이 방법은 저장 엔진과 편집 구간을 바꾸지 않습니다.

페이지형은 main에 data-su-pages / su-pages와 작성자가 나눈 .su-page 절을 두고 --profile pages를 사용합니다. 자동 페이지 분할을 하지 않습니다. 화면에서는 내용이 늘어나며 인쇄 분량을 따로 확인합니다.

--theme, --color-scheme, --density, --profile은 새 문서의 선택값입니다. --theme-key는 밝기 선택을 저장하는 키입니다. 기본값은 openai/system/comfortable/continuous입니다.

필요한 CSS·JS·이미지·폰트를 결과 HTML에 내장합니다. 수신자는 설치나 프로젝트 폴더가 필요 없습니다. SDK 네트워크 조회나 런타임 코드 갱신은 없습니다. 편집·검색·취소/실패 시 미저장 상태와 현재 저장 시점의 스냅샷을 유지합니다.

## 명시적 갱신

```sh
python3 -B tools/document.py update old.html new.html --from-sdk /path/to/old/sdk
python3 -B tools/document.py update old.html new.html --from-sdk /path/to/old/sdk --inline-editing
python3 -B tools/document.py export linked.html portable.html
```

기존 본문·편집 ID·설정을 보존하고 새 파일에 씁니다. --inline-editing은 지원되는 문단을 명시적으로 전환하며, 지원하지 않는 구조는 그대로 둡니다. 일반 SDK 갱신이나 batch-update는 편집 구조를 자동 전환하지 않습니다. 관리 자산을 직접 변경한 문서는 자동 갱신을 중단합니다. batch-update는 1.x → 2.x 같은 주요 버전 전환을 보류합니다. 기존 소비 앱을 자동으로 변경하지 않습니다.

lib/assets의 여섯 파일은 독립 문서용 묶음이며 manifest.json의 해시로 확인합니다. 이 조합용 묶음과 개별 CSS 진입점을 구분합니다. upstream의 원본 고지와 라이선스를 함께 배포합니다.
