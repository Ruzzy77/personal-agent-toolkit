import type {ComponentProps, ReactNode, RefObject} from 'react';
import {Select} from '@openai/apps-sdk-ui/components/Select';
import {CopyTooltip} from '@openai/apps-sdk-ui/components/Tooltip';
import {Button} from '@openai/apps-sdk-ui/components/Button';

export type DialogCloseReason = 'backdrop' | 'close-button' | 'escape' | 'native' | 'viewport';
export type OpenChangeHandler = (open: boolean, detail: {reason: DialogCloseReason}) => void;

export function NamedControl(props: {label: string; selector?: string; restoreFocus?: boolean; visibleLabel?: boolean; description?: ReactNode; children: ReactNode}): ReactNode;
export function FieldSelect(props: ComponentProps<typeof Select> & {'aria-label': string; visibleLabel?: boolean; restoreFocus?: boolean; description?: ReactNode}): ReactNode;
export function Field(props: {label: string; description?: ReactNode; children: ReactNode}): ReactNode;
export function KeyboardCopyTooltip(props: ComponentProps<typeof CopyTooltip>): ReactNode;
export function installCalendarNames(root?: Document | HTMLElement): () => void;

export function Dialog(props: {
  open: boolean;
  onOpenChange: OpenChangeHandler;
  title: ReactNode;
  children: ReactNode;
  placement?: 'center' | 'left' | 'right';
  returnFocusRef?: RefObject<HTMLElement | null>;
  initialFocusRef?: RefObject<HTMLElement | null>;
  closeLabel?: string;
  closeOnBackdrop?: boolean;
  className?: string;
  'aria-describedby'?: string;
}): ReactNode;

export function NavigationAction(props: ComponentProps<typeof Button> & {
  current?: boolean;
  children: ReactNode;
}): ReactNode;

export function ResponsiveNavigation(props: {
  open: boolean;
  onOpenChange: OpenChangeHandler;
  title: string;
  label?: string;
  returnFocusRef?: RefObject<HTMLElement | null>;
  children: ReactNode;
  className?: string;
  dialogClassName?: string;
}): ReactNode;

export {initPageNavigation} from './page-navigation.js';

export function UIKitRoot(props: {
 theme?: 'openai' | 'editorial-ko' | (string & {});
 colorScheme?: 'system' | 'light' | 'dark' | 'inherit';
 density?: 'comfortable' | 'compact';
 children: ReactNode; className?: string;
}): ReactNode;
