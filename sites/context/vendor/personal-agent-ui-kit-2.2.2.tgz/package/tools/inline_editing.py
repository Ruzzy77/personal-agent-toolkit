"""Inline editing contracts. Parse existing markup without reserializing it."""
import html
import json
import re
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit

POLICY = json.loads((Path(__file__).resolve().parents[1] / 'lib/inline-policy.json').read_text())
BLOCKS = set(POLICY['blocks'])
INLINE = set(POLICY['html'] + POLICY['math'])
VOID = set('area base br col embed hr img input link meta param source track wbr'.split())
RUNTIME = set(POLICY['runtimeAttributes'])


def valid_inline(tag, attrs):
    if tag not in INLINE:
        return False
    allowed = set(POLICY['commonAttributes']) | RUNTIME
    if tag in POLICY['math']:
        allowed.update(POLICY['mathAttributes'])
    if tag == 'a':
        allowed.update(POLICY['linkAttributes'])
    if any(k not in allowed for k in attrs):
        return False
    if 'href' in attrs:
        value = re.sub(r'[\x00-\x20]+', '', attrs['href'])
        if urlsplit(value).scheme.lower() not in {'', 'https', 'http', 'mailto'}:
            return False
    return True


class Markup(HTMLParser):
    """Byte-preserving element ranges for an explicit editing-mode migration."""
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.text, self.nodes, self.stack = text, [], []
        self.starts = [0]
        self.starts.extend(m.end() for m in re.finditer('\n', text))

    def source_offset(self):
        line, column = self.getpos()
        return self.starts[line - 1] + column

    def handle_starttag(self, tag, pairs):
        attrs = dict(pairs)
        node = {'tag': tag, 'attrs': attrs, 'start': self.source_offset(), 'open_end': self.source_offset() + len(self.get_starttag_text()),
                'parent': self.stack[-1] if self.stack else None, 'end': None}
        self.nodes.append(node)
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            self.stack.append(node)
        else:
            node['end'] = node['open_end']

    def handle_endtag(self, tag):
        if not self.stack or self.stack[-1]['tag'] != tag:
            raise ValueError('Unbalanced document markup')
        node = self.stack.pop()
        node['close_start'] = self.source_offset()
        node['end'] = self.text.index('>', self.source_offset()) + 1

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if self.stack and self.stack[-1] is self.nodes[-1]:
            node = self.stack.pop()
            node['close_start'] = node['open_end']
            node['end'] = node['open_end']


def enable_inline_editing(text):
    parser = Markup(text)
    parser.feed(text)
    if parser.stack:
        raise ValueError('Incomplete document markup')
    ids = {n['attrs']['data-edit-id'] for n in parser.nodes if 'data-edit-id' in n['attrs']}
    patches, claimed = [], []
    for node in parser.nodes:
        attrs = node['attrs']
        if node['tag'] not in BLOCKS or attrs.get('data-edit-mode') == 'inline':
            continue
        if any(start <= node['start'] < end for start, end in claimed):
            continue
        descendants = [n for n in parser.nodes if node['open_end'] <= n['start'] < node.get('close_start', node['open_end'])]
        if not descendants or not all(valid_inline(n['tag'], n['attrs']) for n in descendants):
            continue
        fields = [n for n in descendants if n['attrs'].get('data-edit-id')]
        if not attrs.get('data-edit-id') and not fields:
            continue
        # Never turn a child of an existing editing field into another editor.
        parent = node['parent']
        if any(p['attrs'].get('data-edit-id') for p in ancestors(parent)):
            continue
        extra = ' data-edit-mode="inline"'
        if not attrs.get('data-edit-id'):
            base = 'inline-' + fields[0]['attrs']['data-edit-id']
            key, suffix = base, 1
            while key in ids:
                key = base + '-' + str(suffix)
                suffix += 1
            ids.add(key)
            extra += ' data-edit-id="' + html.escape(key, quote=True) + '"'
        patches.append((node['open_end'] - 1, extra))
        claimed.append((node['start'], node['end']))
    for offset, extra in reversed(patches):
        text = text[:offset] + extra + text[offset:]
    return text


def ancestors(node):
    while node:
        yield node
        node = node['parent']
