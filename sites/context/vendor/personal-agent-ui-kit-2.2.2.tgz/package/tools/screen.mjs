import {readFile, writeFile, mkdir, mkdtemp, rm, rename} from 'node:fs/promises';
import {dirname, resolve, join} from 'node:path';
import {tmpdir} from 'node:os';
import {createRequire} from 'node:module';
import {fileURLToPath, pathToFileURL} from 'node:url';

const escapeHTML = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const layers = '@layer theme, base, components, utilities;';
/** Bundle one authored React component, not a page template or document editor. */
export async function buildScreen({entry, title, sdk=resolve(dirname(fileURLToPath(import.meta.url)), '..'), styles=[]}) {
  entry=resolve(entry); sdk=resolve(sdk);
  const pkg=JSON.parse(await readFile(join(sdk,'package.json'),'utf8'));
  if(pkg.name!=='@personal-agent/ui-kit') throw Error('선택한 SDK를 확인해 주세요.');
  const req=createRequire(join(sdk,'package.json'));
  let build, tailwindcss, upstreamCSS, upstreamRoot, tailwindRoot;
  try {
    ({build}=await import(pathToFileURL(req.resolve('vite')).href));
    tailwindcss=(await import(pathToFileURL(req.resolve('@tailwindcss/vite')).href)).default;
    upstreamCSS=req.resolve('@openai/apps-sdk-ui/css');
    upstreamRoot=dirname(upstreamCSS);
    tailwindRoot=dirname(req.resolve('tailwindcss/package.json'));
    for(const name of ['react','react-dom/client']) req.resolve(name);
  } catch(error) { throw new Error('공통 제작 환경의 고정 의존성을 설치해 주세요. 자동으로 설치하지 않습니다.',{cause:error}); }
  const work=await mkdtemp(join(tmpdir(),'uikit-screen-'));
  try {
    const cssFile=join(work,'screen.css'), mount=join(work,'mount.jsx');
    const imports=[join(tailwindRoot,'index.css'),upstreamCSS,join(sdk,'lib/react.css'),join(sdk,'lib/layout.css'),...styles.map(p=>resolve(p))];
    await writeFile(cssFile,layers+'\n'+imports.map(p=>'@import '+JSON.stringify(p)+';').join('\n')+
      '\n@source '+JSON.stringify(upstreamRoot)+';\n@source '+JSON.stringify(dirname(entry))+';\nbody{margin:0;background:var(--su-paper);color:var(--su-ink);}\n');
    await writeFile(mount,'import '+JSON.stringify(cssFile)+';\nimport React from "react";import {createRoot} from "react-dom/client";import App from '+JSON.stringify(entry)+';\ncreateRoot(document.getElementById("root")).render(<App/>);');
    const resolveShared={name:'uikit-screen-dependencies',enforce:'pre',resolveId(id) {
      if(/^(?:https?:|\/\/)/i.test(id)) throw Error('외부 코드 대신 제작 환경에 설치한 의존성을 사용해 주세요: '+id);
      if(id.startsWith('@personal-agent/ui-kit/')) {
        const key='./'+id.slice('@personal-agent/ui-kit/'.length), spec=pkg.exports[key];
        const target=typeof spec==='string'?spec:spec?.default;
        if(!target) throw Error('SDK에서 제공하지 않는 경로입니다: '+id);
        return resolve(sdk,target);
      }
      if(id.startsWith('.')||id.startsWith('/')||id.startsWith('\0')) return null;
      if(/^[a-z][a-z\d+.-]*:/i.test(id)) return null;
      try { return req.resolve(id); } catch { throw Error('공통 제작 환경에 없는 의존성입니다: '+id); }
    }};
    const result=await build({configFile:false,envDir:false,root:work,plugins:[resolveShared,tailwindcss()],logLevel:'warn',
      define:{'process.env.NODE_ENV':'"production"','import.meta.env':'{}','import.meta':'{}'},
      build:{write:false,minify:true,cssCodeSplit:false,lib:{entry:mount,formats:['iife'],name:'UIKitScreen',fileName:'screen',cssFileName:'screen'}}});
    const output=(Array.isArray(result)?result[0]:result).output;
    if(output.some(x=>x.type==='asset'&&!x.fileName.endsWith('.css'))) throw Error('독립 HTML에 포함되지 않은 출력 파일이 있습니다.');
    if(output.filter(x=>x.type==='chunk').length!==1) throw Error('JavaScript를 하나의 파일로 묶지 못했습니다.');
    let css=layers+'\n'+output.filter(x=>x.type==='asset').map(x=>x.source).join('\n');
    // The pinned Apps SDK CSS references KaTeX's CDN. Use its installed, licensed fonts offline.
    const fontURLs=[...new Set(css.match(/https:\/\/cdn\.openai\.com\/common\/fonts\/katex\/[A-Za-z0-9_-]+\.woff2/g)||[])];
    if(fontURLs.length) {
      const katex=dirname(req.resolve('katex/package.json'));
      for(const url of fontURLs) {
        const bytes=await readFile(join(katex,'dist/fonts',url.split('/').at(-1)));
        css=css.split(url).join('data:font/woff2;base64,'+bytes.toString('base64'));
      }
      css+='\n/*! '+(await readFile(join(katex,'LICENSE'),'utf8')).replace(/\*\//g,'* /')+' */';
    }
    if(/(?:url\(\s*["']?|@import\s*["'])(?:https?:|\/\/)/i.test(css)) throw Error('외부 스타일 자산을 HTML에 포함해 주세요.');
    const js=output.find(x=>x.type==='chunk').code.replace(/<\/script/gi,'<\\/script');
    return '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+escapeHTML(title)+'</title><style>'+css.replace(/<\/style/gi,'<\\/style')+'</style></head><body><div id="root"></div><script>'+js+'</script></body></html>';
  } finally { await rm(work,{recursive:true,force:true}); }
}
export async function writeScreen(options) {
  const output=resolve(options.output);
  if(output===resolve(options.entry)) throw Error('입력 파일과 출력 파일은 달라야 합니다.');
  const html=await buildScreen(options);
  await mkdir(dirname(output),{recursive:true});
  const staging=await mkdtemp(join(dirname(output),'.uikit-screen-'));
  try { const file=join(staging,'output.html');await writeFile(file,html);await rename(file,output); }
  finally { await rm(staging,{recursive:true,force:true}); }
  return output;
}
if(process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  try {
    const args=process.argv.slice(2); const positional=[],options={};
    while(args.length) { const arg=args.shift();if(['--title','--sdk'].includes(arg)){if(!args.length)throw Error(arg+' 값이 필요합니다.');options[arg.slice(2)]=args.shift();}else positional.push(arg); }
    if(positional.length!==2||!options.title) throw Error('사용법: screen App.jsx output.html --title "제목" [--sdk SDK]');
    const output=await writeScreen({...options,entry:positional[0],output:positional[1]});
    console.log(output);
  } catch(error) { console.error(error.message); if(error.cause)console.error(error.cause.message);process.exitCode=1; }
}
