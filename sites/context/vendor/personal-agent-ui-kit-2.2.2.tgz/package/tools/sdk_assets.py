"""Read and install immutable UI Kit release assets without network access."""
import hashlib
import html
import json
import re
import argparse
from pathlib import Path
from urllib.parse import urlsplit


ASSET_ORDER = ('tokens.css', 'seomun.css', 'document.css', 'lucide.js', 'seomun.js', 'document.js')


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def safe_js(text):
    return re.sub(r'</script', r'<\\/script', text, flags=re.I)


class Package:
    """Verified projection of one immutable @personal-agent/ui-kit release."""

    def __init__(self, root):
        root = Path(root).expanduser().resolve()
        if (root / 'packages/ui-kit/manifest.json').is_file():
            root /= 'packages/ui-kit'
        self.root = root
        self.manifest = json.loads((root / 'manifest.json').read_text())
        if self.manifest.get('name') != '@personal-agent/ui-kit' or self.manifest.get('documentSchema') != 'editable-report-v1':
            raise ValueError('Unsupported UI Kit package')
        self.version = self.manifest['version']
        template = root / 'templates/document-shell.html'
        self.template = template.read_text() if template.is_file() else None
        self.assets = {}
        for name, item in self.manifest['assets'].items():
            path = (root / item['path']).resolve()
            if not path.is_relative_to(root):
                raise ValueError('Asset path is outside the package')
            raw = path.read_text()
            content = safe_js(raw) if name.endswith('.js') else raw
            if digest(content) != item['sha256']:
                raise ValueError(f'Package asset modified: {name}')
            self.assets[name] = content

    def for_version(self, version):
        if version == self.version:
            return self
        if not re.fullmatch(r'\d+\.\d+\.\d+(?:-[\w.-]+)?', version):
            raise ValueError('Invalid SDK version')
        candidates = [self.root.parent / version]
        for parent in self.root.parents:
            candidates.extend([parent / 'dist/releases' / version, parent / 'releases' / version])
        for candidate in candidates:
            if (candidate / 'manifest.json').is_file():
                package = Package(candidate)
                if package.version == version:
                    return package
        raise ValueError(f'SDK {version} is not installed; provide its package explicitly')

    def names(self, names=None):
        selected = tuple(names or ASSET_ORDER)
        unknown = [name for name in selected if name not in self.assets]
        if unknown:
            raise ValueError(f'Unknown UI Kit assets: {", ".join(unknown)}')
        return selected

    def metadata(self, mode, base=None, names=None, *, schema=None):
        selected = self.names(names)
        schema = schema or self.manifest['documentSchema']
        if schema not in self.manifest.get('documentSchemas', [self.manifest['documentSchema']]):
            raise ValueError('Selected SDK does not support this document schema')
        data = {
            'sdkVersion': self.version,
            'documentSchema': schema,
            'assetMode': mode,
            'assetHashes': {name: self.manifest['assets'][name]['sha256'] for name in selected},
        }
        if mode == 'linked':
            data['assetBase'] = base
        return data

    def application_metadata(self, profile, mode='embedded', names=None):
        selected = self.names(names)
        return {
            'sdk': self.manifest['name'],
            'sdkVersion': self.version,
            'assetMode': mode,
            'profile': profile,
            'assetHashes': {name: self.manifest['assets'][name]['sha256'] for name in selected},
        }

    def asset_tags(self, mode, base=None, names=None, *, attribute='data-doc-asset', include_version=False, flat_links=False):
        selected = self.names(names)
        if mode not in {'embedded', 'linked'}:
            raise ValueError('Asset mode must be embedded or linked')
        if mode == 'linked':
            url = urlsplit(base or '')
            if not base or url.scheme or url.netloc or '?' in base or '#' in base:
                raise ValueError('Linked assets require a same-origin path, not a CDN URL')
        tags = []
        for name in selected:
            escaped = html.escape(name, quote=True)
            marker = f'{attribute}="{escaped}"'
            if include_version:
                marker += f' data-ui-kit-version="{html.escape(self.version, quote=True)}"'
            if mode == 'embedded':
                tag = 'style' if name.endswith('.css') else 'script'
                tags.append(f'<{tag} {marker}>{self.assets[name]}</{tag}>')
            else:
                relative = Path(self.manifest['assets'][name]['path']).name if flat_links else self.manifest['assets'][name]['path']
                url = html.escape(base.rstrip('/') + '/' + relative, quote=True)
                if name.endswith('.css'):
                    tags.append(f'<link rel="stylesheet" {marker} href="{url}">')
                else:
                    tags.append(f'<script {marker} src="{url}" defer></script>')
        return tags

    def install_flat(self, destination, names=None, *, include_notices=True):
        """Install a selected immutable browser bundle into an empty/versioned folder."""
        destination = Path(destination).expanduser().resolve()
        selected = self.names(names)
        files = [(self.root / self.manifest['assets'][name]['path'], destination / name) for name in selected]
        notice = self.root / 'upstream/THIRD_PARTY_NOTICES.txt'
        if include_notices and notice.is_file():
            files.append((notice, destination / notice.name))
        for source, target in files:
            if target.exists() and target.read_bytes() != source.read_bytes():
                raise ValueError(f'Existing UI Kit asset differs: {target}')
        for source, target in files:
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as stream:
                    stream.write(source.read_bytes())
        return [str(target) for _, target in files]


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    source = commands.add_parser('source')
    source.add_argument('--sdk', default=str(Path(__file__).resolve().parents[1]))
    install = commands.add_parser('install')
    install.add_argument('destination', type=Path)
    install.add_argument('--sdk', default=str(Path(__file__).resolve().parents[1]))
    install.add_argument('--name', dest='names', action='append', required=True)
    install.add_argument('--versioned', action='store_true')
    args = parser.parse_args(argv)
    try:
        package = Package(args.sdk)
        if args.command == 'source':
            result = {'package': package.manifest['name'], 'version': package.version, 'sdk': str(package.root)}
        else:
            destination = args.destination.expanduser().resolve()
            if args.versioned:
                destination /= package.version
            result = {'version': package.version, 'files': package.install_flat(destination, args.names)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(1, f'UI Kit: {error}\n')


if __name__ == '__main__':
    main()
