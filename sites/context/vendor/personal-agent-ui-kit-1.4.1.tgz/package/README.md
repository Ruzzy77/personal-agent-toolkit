# @personal-agent/ui-kit

UI Kit의 공통 스타일, 공식 Apps SDK UI의 호환 보완, 편집 가능한 독립 HTML 제작 도구입니다. 카탈로그·업무 데이터·인증·서버 저장은 포함하지 않습니다.

## 설치와 버전

배포된 `personal-agent-ui-kit-1.4.1.tgz`를 앱에 보관하고 `file:` 의존성으로 고정합니다. 공개 레지스트리나 UI Kit 사이트에 런타임 접속할 필요가 없습니다. 릴리스는 불변이며 업데이트할 때 패키지와 앱 배포를 함께 갱신합니다.

## HTML

```js
import '@personal-agent/ui-kit/html.css';
import {init} from '@personal-agent/ui-kit/html';
init(document);
```

상단바는 `.su-appbar > .su-appbar__inner`를 사용합니다. 상단바의 보조 도구만 `details[data-su-tools]`로 모읍니다. 동적 삽입 후 `init(영역)`을 호출합니다. `.su-*`, `Seomun`, `SUIcons`는 기존 파일 호환을 위해 유지합니다.

빌드 없는 HTML에서는 묶음의 `lib/assets/tokens.css`, `seomun.css`와 `lucide.js`, `seomun.js`를 차례로 연결할 수 있습니다. 파일 한 개로 공유할 문서는 아래 제작 도구로 내장합니다.

## React

React 18/19, 고정된 `@openai/apps-sdk-ui@0.2.2`, 기존 Tailwind 4를 앱에서 사용합니다. React와 공식 구성 요소를 이 패키지에 중복 번들하지 않습니다. 앱 아이콘은 `lucide-react@1.44.0`, 공식 슬롯 크기는 `1em`입니다.

```css
@import "tailwindcss";
@import "@openai/apps-sdk-ui/css";
@import "@personal-agent/ui-kit/react.css";
@source "../node_modules/@openai/apps-sdk-ui/dist/es";
```

`@source`는 해당 CSS 파일 기준의 설치 경로로 맞춥니다. 공식 구성 요소는 `@openai/apps-sdk-ui/components/...`에서 직접 import합니다. HTML 전역 리셋 대신 `react.css`를 사용합니다.

```jsx
import {Field, FieldSelect} from '@personal-agent/ui-kit/react';
import {Input} from '@openai/apps-sdk-ui/components/Input';
<Field label="문서 이름"><Input value={title} onChange={onTitleChange}/></Field>
<FieldSelect visibleLabel aria-label="분류" options={options} value={kind} onChange={onKindChange}/>
```

이름과 키보드 보완은 공식 0.2.2의 제약에 한정됩니다. `installCalendarNames(root)`는 해제 함수를 반환하므로 사용하는 화면의 effect에서 호출·해제합니다. 필요 없는 화면에는 설치하지 않습니다.

### 대화상자와 반응형 탐색

`Dialog`는 네이티브 모달의 포커스 유지와 Escape 동작을 사용하고, 외형은 `.su-dialog`와 공식 대화상자 토큰을 사용합니다. 열림 상태는 소비자가 관리합니다. 메뉴 항목에서 열 때에는 사라지지 않는 메뉴 버튼 ref를 `returnFocusRef`로 넘깁니다.

```jsx
import {useRef, useState} from 'react';
import {Dialog} from '@personal-agent/ui-kit/react';

const trigger = useRef(null);
const [open, setOpen] = useState(false);

<button ref={trigger} onClick={() => setOpen(true)}>설정</button>
<Dialog
  open={open}
  onOpenChange={setOpen}
  title="설정"
  placement="right"
  returnFocusRef={trigger}
>
  {/* 설정 내용 */}
</Dialog>
```

`placement`는 `center`, `left`, `right`를 지원합니다. 긴 내용은 대화상자 본문에서 스크롤합니다. 닫기 버튼, Escape와 배경 클릭은 `onOpenChange(false, {reason})`를 호출합니다.

`ResponsiveNavigation`은 같은 탐색 내용을 넓은 화면의 `aside`와 767px 이하의 왼쪽 모달 사이에서 전환합니다. 모달 상태와 열기 버튼은 소비자가 관리합니다. 화면이 넓어지는 동안 모달이 열려 있으면 닫고 현재 위치 또는 첫 탐색 항목으로 포커스를 옮깁니다.

```jsx
import {NavigationAction, ResponsiveNavigation} from '@personal-agent/ui-kit/react';

<div className="kit-navigation-layout">
  <ResponsiveNavigation
    open={navigationOpen}
    onOpenChange={setNavigationOpen}
    title="Toolkit"
    returnFocusRef={navigationTrigger}
  >
    <nav className="su-stack" aria-label="화면">
      <NavigationAction current={screen === 'work'} onClick={() => go('work')}>작업</NavigationAction>
      <NavigationAction current={screen === 'files'} onClick={() => go('files')}>파일</NavigationAction>
    </nav>
  </ResponsiveNavigation>
  <main className="kit-navigation-main">{/* 화면 */}</main>
</div>
```

탐색의 화면 이름, 경로, 구역과 상태는 소비자가 정합니다. `NavigationAction`은 현재 위치와 긴 이름의 줄임만 공통으로 처리하며, 제품 정보 구조를 만들지 않습니다.

## 문서

실행 환경은 Python 3.10 이상과 표준 라이브러리입니다. 수신자는 Python 없이 HTML만 열면 됩니다. `tools/document.py`가 버전과 관리 자산을 확인하고 새 출력 파일을 만듭니다.

```sh
python3 tools/document.py document main.html report.html
python3 tools/document.py check report.html
python3 tools/document.py update report.html updated.html --sdk /installed/ui-kit/1.4.1
python3 tools/document.py convert report.html linked.html --mode linked
python3 tools/document.py export linked.html standalone.html
```

- `document`: 하나의 `main#report.document`에서 생성. `h1#report-title.report-title`과 고유한 일반 텍스트 `data-edit-id`가 필요합니다. 절은 `section.chapter`와 편집 가능한 `h2.chapter-title`을 씁니다.
- `update` (`reapply` 호환 이름): 현재 저장된 본문·설정·편집 ID를 그대로 두고 SDK 자산 묶음만 교체합니다. `--from-sdk`로 이전 SDK를 지정할 수 있습니다.
- `convert`: 버전은 유지하며 `--mode embedded|linked`로 포함 방식을 바꿉니다. 기본 연결형 자산은 출력 옆 `ui-kit/<버전>/`에 만듭니다. `--asset-base`를 지정하면 앱이 그 같은 출처 경로를 제공해야 합니다. 연결형은 HTTP(S)로 제공합니다.
- `export`: 연결형을 인터넷 없이 동작하는 단일 HTML로 내장합니다. 문서 이미지도 미리 data URL로 포함해야 합니다. 외부 업무 링크를 따라가거나 서버 기능을 오프라인 기능으로 바꾸지 않습니다.
- `check`: 문서가 선택한 릴리스를 기준으로 확인합니다. SDK 원본이 최신이 됐다는 이유만으로 예전 문서를 오류로 보지 않습니다. 예전 버전이 없으면 그 버전의 패키지를 제공해야 합니다.

`#document-data`의 문서 형식 `editable-report-v1`, `ui-kit-document` 프로필 1.3.0, `#ui-kit-meta`의 SDK 버전은 구분합니다. `data-doc-asset` 식별자와 메타데이터는 브라우저 저장 후에도 유지됩니다. 관리 자산의 직접 수정이나 알 수 없는 형식은 자동 교체를 중단합니다. 원본과 이미 존재하는 출력은 덮어쓰지 않습니다.

여러 관리형 문서는 먼저 조회한 뒤 같은 파일명으로 갱신할 수 있습니다. 폴더 하위 탐색은 `--recursive`, 실제 반영은 `--apply`를 명시합니다. 조회는 파일을 바꾸지 않습니다.

```sh
python3 tools/document.py batch-update reports --recursive --version 1.4.1
python3 tools/document.py batch-update reports --recursive --version 1.4.1 --apply
```

일괄 갱신은 내장형·연결형을 유지하며 본문과 설정을 보존합니다. 문서에 꼭 필요한 별도 스타일·동작은 `data-app-asset`으로 공통 자산과 구분합니다. 수정된 공통 자산, 앱이 제공하는 별도 자산 경로와 알 수 없는 형식은 해당 제작 경로에서 처리하도록 보류합니다. 적용 중에는 같은 폴더의 임시 파일을 사용하고 확인 뒤 원본을 원자적으로 교체합니다.

## 생성형 화면의 자산

자체 저장·데이터 처리를 가진 화면은 문서 엔진을 중복 삽입하지 않고 필요한 자산만 선택합니다. Python 생성기는 `tools/sdk_assets.py`의 `Package`를 사용하거나 정적 묶음을 설치합니다.

```sh
python3 tools/sdk_assets.py install public/ui-kit --versioned \
  --name tokens.css --name seomun.css --name lucide.js --name seomun.js
```

`Package.asset_tags()`는 내장형 태그와 공통 메타데이터를 만들고, `install_flat()`은 선택한 자산과 제3자 고지를 불변 버전 폴더에 설치합니다.

문서 전용 ESM 진입점 `document`는 공통 셸이 있는 브라우저 문서에서 `save({download})`, `snapshot()`, `isDirty()`를 제공합니다. CSS는 `html.css`와 `document.css`를 함께 사용합니다. 기존 파일 저장은 사용자 조작에서 실행하며 취소·실패를 저장 완료로 표시하지 않습니다.

## 표의 열 너비

일반 HTML·React의 `.su-table`과 문서 본문 표는 내용에 따라 열 너비를 나눕니다. 짧은 항목명과 긴 설명을 같은 폭으로 강제하지 않으며, 화면 크기와 편집 내용에 따라 브라우저가 다시 배치합니다. 별도 측정 스크립트는 필요하지 않습니다.

```html
<div class="su-table-wrap">
  <table class="su-table"><!-- 내용에 따른 열 너비 --></table>
</div>

<table class="su-table" data-layout="fixed"><!-- 같은 폭의 비교 열 --></table>
```

열의 의미상 폭이 정해져 있으면 `colgroup`으로 지정합니다. `data-layout="fixed"`와 함께 쓰면 지정한 폭을 우선하고 나머지 열을 나눕니다. 문서 본문 표에서도 같은 속성을 사용합니다. 긴 단어는 셀 안에서 줄바꿈하며, 여러 열의 표는 기존 가로 스크롤을 유지합니다. 본문을 생략하거나 글자를 자동으로 축소하지 않습니다.

## 페이지형 문서

기본 문서는 연속형입니다. 페이지형은 콘텐츠에 구분을 명시하는 선택 옵션이며 자동 조판·본문 재분할·발표 모드는 포함하지 않습니다.

```html
<main id="report" class="document su-pages" data-su-pages>
  <section class="su-page" id="cover"><!-- 표지 --></section>
  <section class="su-page chapter" id="scope"><!-- 본문 --></section>
</main>
```

`templates/document-pages.html`은 편집 가능한 시작 본문입니다. 페이지를 나누는 위치와 각 페이지의 내용은 제작자가 정합니다. 일반 문서와 같은 제작 도구를 사용합니다.

```sh
python3 tools/document.py document templates/document-pages.html pages.html
```

- `.su-pages`는 페이지 사이 간격과 최대 폭, `.su-page`는 용지 형태와 내부 여백을 맡습니다. HTML·React 모두 같은 클래스를 사용합니다.
- 화면은 A4 세로 비율을 기본으로 하되 내용이 길면 자연스럽게 늘어납니다. 좁은 화면에서는 비율을 강제하지 않고 공통 16px 여백으로 읽습니다. 내용 잘라내기·자동 축소·편집 후 조판은 없습니다.
- 문서 셸은 이전·다음 버튼과 현재 페이지를 표시합니다. 페이지가 하나면 탐색은 숨깁니다. 페이지 수는 직접 작성한 `.su-page`의 수이며 인쇄 쪽수가 아닙니다.
- 인쇄는 작성자가 구분한 페이지 앞에서 새 장을 시작합니다. 긴 내용은 브라우저가 다음 장으로 이어 출력하므로 화면과 인쇄의 쪽수는 다를 수 있습니다.
- 기존 편집·저장·내보내기·버전 갱신을 그대로 사용합니다. 페이지 경계는 본문에 남으며 도구가 본문을 다시 나누지 않습니다.

React와 일반 작업 화면은 동일한 탐색 함수를 명시적으로 연결할 수 있습니다. React에서는 공식 Button을 사용하고 `html.css`나 HTML 런타임을 함께 불러오지 않습니다.

```jsx
import {useEffect, useRef} from 'react';
import {Button} from '@openai/apps-sdk-ui/components/Button';
import {ChevronLeft, ChevronRight} from 'lucide-react';
import {initPageNavigation} from '@personal-agent/ui-kit/react';

function Pages({children}) {
  const pages = useRef(null), controls = useRef(null);
  useEffect(() => {
    const navigation = initPageNavigation(pages.current, controls.current);
    return () => navigation?.destroy();
  }, [children]);
  return <>
    <nav ref={controls} className="su-page-nav" aria-label="페이지 탐색" hidden>
      <Button variant="ghost" color="secondary" aria-label="이전 페이지" data-su-page-step="-1"><ChevronLeft size="1em"/></Button>
      <span data-su-page-position/>
      <Button variant="ghost" color="secondary" aria-label="다음 페이지" data-su-page-step="1"><ChevronRight size="1em"/></Button>
    </nav>
    <div ref={pages} className="su-pages">{children}</div>
  </>;
}
```

탐색은 페이지 요소의 위치만 읽습니다. 내용을 추가·제거한 일반 HTML은 `Seomun.init(영역)` 또는 반환된 `refresh()`를 호출합니다. 화면을 해제할 때 `destroy()`를 호출합니다. 자동 단축키·추가 편집기·서버·외부 런타임은 설치하지 않습니다.

## 공통 기준

슬로건·장식·중복 설명은 생략합니다. 입력·선택·토글의 목적과 필수 상태·복구 이름은 짧게 보이도록 남깁니다. 익숙한 아이콘 조작에는 호버·초점 이름을 둡니다. 배지는 아이콘 전용·텍스트·혼합을 용도에 맞게 사용합니다.

배치의 바깥 간격은 부모가 정합니다. 나란한 도구는 `.su-row`의 8px, 같은 영역의 세로 묶음은 `.su-stack`의 12px, 별도 절은 `--su-section-gap`의 32px를 사용합니다. 메뉴 자체는 자동 바깥 여백을 갖지 않으며 상단바만 끝 정렬합니다.

패딩·높이·초점·색상은 패키지에서 고칩니다. 소비 화면에는 콘텐츠 배치와 업무 동작만 둡니다. HTML 어댑터의 동작이 공식 React 라이브러리와 동일하다고 표시하지 않습니다.

## 배치 조합

`html.css`와 `react.css` 모두 같은 배치 클래스를 제공합니다. 카탈로그의 `kit-*`, `example-*` CSS를 복사할 필요가 없습니다.

| 역할 | 공통 클래스 |
| --- | --- |
| 나란한 조작 | `.su-row` · 8px · 줄바꿈 |
| 같은 영역의 세로 묶음 | `.su-stack` · 12px |
| 절 사이 | `.su-stack[data-gap="section"]` · 32px |
| 입력·카드 열 | `.su-grid` · 16px · 공간 부족 시 한 열 |
| 제목·필터와 도구 | `.su-toolbar` · 12px · 아래쪽 정렬 |
| 제목과 내용 | `.su-section` · 12px |
| 패널 | `.su-panel` · 내부 16px |
| 작업 화면 | `.su-workspace` · 최대 72rem |

```html
<main class="su-workspace su-stack" data-gap="section">
  <h1>자료 관리</h1>
  <section class="su-section">
    <div class="su-toolbar">
      <h2>자료 목록</h2>
      <div class="su-row"><!-- 관련 조작 --></div>
    </div>
    <div class="su-grid"><!-- label.su-field 또는 React Field --></div>
  </section>
</main>
```

그리드는 최대 두 열이며 `data-columns="3"`으로 세 열을 선택합니다. 기본 최소 열 폭은 14rem이고 남은 공간이 작으면 한 열로 줄입니다. 본문·차트처럼 읽기 폭이 다른 콘텐츠는 부모에서 `--su-column-min`만 선택합니다. 입력 옆 확인 버튼은 `.su-row[data-align="end"]`, 독립 HTML의 외부 아이콘 입력과 같은 시작선에 놓을 동작은 `.su-field-actions[data-leading-icon]`을 씁니다.

명시적인 gap 레이아웃 안에서는 문단·목록·제목의 기본 바깥 여백을 합산하지 않습니다. 문서 본문의 읽기 간격과 모달·팝오버의 위치 규칙은 별개입니다. 그리드에서 오류 문구가 늘어나도 이웃 입력을 늘려 빈칸을 채우지 않습니다.

## 라이선스

Apps SDK UI의 MIT 고지와 Lucide의 ISC 고지는 `upstream/` 및 해당 자산 안에 포함합니다. UI Kit 자체는 내부 배포 패키지입니다.

## 1.0.1

상단바 끝 정렬을 해당 부모에 한정했습니다. 본문 도구 간격은 부모 행이 유지하며, 메뉴 버튼의 인라인 기준선 여백을 제거했습니다. 문서 형식과 저장 동작은 바꾸지 않았습니다.

## 1.1.0

HTML·React가 함께 쓰는 배치 조합을 추가했습니다. 입력 행의 오류·힌트, 외부 아이콘의 시작선, 탭의 가로 넘침과 대화상자 동작 줄바꿈을 정리했습니다. 카탈로그 전용 배치 의존과 모달 여백 간섭을 제거했습니다. 문서 내용·편집 ID·저장 동작은 유지합니다.

## 1.2.0

선택형 페이지 구성과 HTML·React 공통 페이지 탐색을 추가했습니다. 연속형 문서, 공식 구성 요소 버전, 문서 프로필과 저장 형식은 유지합니다.

## 1.3.0

공통 자산 읽기·선택·설치를 재사용 모듈로 분리했습니다. 관리형 문서의 조회형 일괄 갱신과 원자적 원본 반영을 추가했으며, 생성형 화면은 필요한 자산만 같은 릴리스에서 설치할 수 있습니다.

## 1.3.1

HTML 어댑터의 비활성 버튼 배경에 필요한 `--alpha-05` 토큰을 추가하고 적용되지 않던 비활성 투명도 규칙을 정리했습니다. 문서 프로필 버전은 패키지 설정 한 곳에서 읽어 매니페스트·문서 틀·런타임에 전달합니다. 문서 내용·편집 ID·저장 동작과 공식 구성 요소 버전은 유지합니다.

## 1.4.0

React용 제어형 대화상자와 좌우 측면 패널, 메뉴 호출 버튼으로의 포커스 복귀를 추가했습니다. 같은 탐색 내용을 넓은 화면의 의미 있는 탐색 영역과 좁은 화면의 모달 사이에서 전환하며, 화면 확장 때 포커스를 보이는 탐색 항목으로 옮깁니다. 공식 Apps SDK UI 0.2.2와 문서 프로필 1.3.0은 유지합니다.

## 1.4.1

좁은 화면의 모달 탐색에서 긴 항목 이름이 탐색 폭을 늘리지 않도록 최소 너비를 해제했습니다. 14rem 탐색 폭과 말줄임, 화면 안쪽 여백을 유지합니다.
