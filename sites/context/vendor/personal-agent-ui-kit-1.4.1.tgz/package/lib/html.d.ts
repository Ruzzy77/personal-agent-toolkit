export function init(root?: ParentNode): void;
export function notify(message: string, options?: {tone?: string; icon?: string; text?: boolean}): void;
export function copy(text: string, control?: HTMLElement): Promise<boolean>;
export function feedback(control: HTMLElement, icon?: string, message?: string): void;
export function closeTools(group: HTMLDetailsElement, focus?: boolean): void;
export {initPageNavigation} from './page-navigation.js';
