export interface PageNavigation {
  /** Re-read author-added or removed direct .su-page children. */
  refresh(): void;
  /** Zero-based authored page index, not a printed sheet number. */
  goTo(index: number): void;
  destroy(): void;
}
export function initPageNavigation(root: HTMLElement | null, controls: HTMLElement | null): PageNavigation | null;
