export function save(options?: {download?: boolean}): Promise<void>;
export function snapshot(): Promise<string>;
export function isDirty(): boolean;
