from html.parser import HTMLParser
import re

VOID = set("area base br col embed hr img input link meta param source track wbr".split())

class Body(HTMLParser):
    """Check the explicit semantic markup consumed by the common document engine."""
    def __init__(self, reserved, *, fresh):
        super().__init__(convert_charrefs=True)
        self.reserved, self.fresh = reserved, fresh
        self.stack, self.ids, self.chapters = [], set(), []
        self.roots, self.titles = 0, 0

    def handle_starttag(self, tag, attrs):
        pairs = attrs
        attrs = dict(pairs)
        classes = attrs.get("class", "").split()
        if len(attrs) != len(pairs):
            raise ValueError("Duplicate HTML attributes")
        if not self.stack:
            self.roots += 1
            if tag != "main" or attrs.get("id") != "report" or "document" not in classes:
                raise ValueError('Expected one <main class="document" id="report">')
        elif tag == "main":
            raise ValueError("Nested main element")
        if tag in {"html", "head", "body", "style", "link", "meta", "script", "iframe", "object", "embed", "base"}:
            raise ValueError(f"Document body must not include {tag}")
        if any(k.startswith("on") for k in attrs):
            raise ValueError("Inline event handlers are not document content")
        key = attrs.get("id")
        if key:
            if key in self.ids or key in self.reserved or any(c.isspace() for c in key):
                raise ValueError(f"Duplicate, reserved, or invalid HTML ID: {key}")
            self.ids.add(key)
        if key == "report-title":
            if tag != "h1" or "report-title" not in classes or not attrs.get("data-edit-id"):
                raise ValueError("The report title must be an editable h1.report-title")
            self.titles += 1
        chapter = None
        if "chapter" in classes:
            if tag != "section" or not key:
                raise ValueError("Each chapter needs section.chapter and a unique ID")
            chapter = {"id": key, "title": None}
            self.chapters.append(chapter)
        if "chapter-title" in classes:
            parent = next((c for _, c in reversed(self.stack) if c is not None), None)
            if tag != "h2" or not attrs.get("data-edit-id"):
                raise ValueError("Each chapter needs one editable h2.chapter-title")
            if parent is None:
                if self.fresh:
                    raise ValueError("Each chapter title must belong to a chapter")
            elif parent["title"] is not None:
                raise ValueError("Each chapter needs one editable h2.chapter-title")
            else:
                parent["title"] = attrs["data-edit-id"]
        if self.fresh:
            if tag in {"form", "input", "button", "select", "textarea", "dialog", "canvas", "svg"}:
                raise ValueError(f"Use the screen workflow for {tag}; do not invent document controls")
            if "style" in attrs and not (tag == "col" and re.fullmatch(r"\s*width\s*:\s*(?:100|[1-9]?\d)(?:\.\d+)?%\s*;?\s*", attrs["style"])):
                raise ValueError("Use common classes, not per-document CSS (only col percentage widths are supported)")
            if "contenteditable" in attrs:
                raise ValueError("The common document runtime owns contenteditable")
            if tag == "img" and ("alt" not in attrs or not re.match(r"data:image/(?:png|jpeg|gif|webp);base64,", attrs.get("src", ""))):
                raise ValueError("Standalone images need embedded PNG/JPEG/GIF/WebP data and alt text")
            if "href" in attrs and re.sub(r"[\x00-\x20]+", "", attrs["href"]).lower().startswith(("javascript:", "vbscript:", "data:")):
                raise ValueError("Unsupported link scheme")
        if tag not in VOID:
            self.stack.append((tag, chapter))

    def handle_endtag(self, tag):
        if not self.stack or self.stack[-1][0] != tag:
            raise ValueError(f"Unbalanced HTML near </{tag}>; close content tags explicitly")
        self.stack.pop()

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_data(self, value):
        if not self.stack and value.strip():
            raise ValueError("Place all document content inside main")

    def finish(self):
        self.close()
        if self.stack or self.roots != 1 or self.titles != 1:
            raise ValueError("Expected one complete main and one report title")
        if any(c["title"] is None for c in self.chapters):
            raise ValueError("A chapter is missing its editable title")

